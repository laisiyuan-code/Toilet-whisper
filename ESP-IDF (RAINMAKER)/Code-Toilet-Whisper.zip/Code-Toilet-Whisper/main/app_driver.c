/*
   Toilet-Whisper Fan Controller – hardware driver
   I2C sensors (VEML7700 + AHT21), LEDC PWM fan, auto-trigger logic.
*/
#include <string.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <esp_log.h>
#include <esp_timer.h>
#include <driver/i2c.h>
#include <driver/ledc.h>

#include <iot_button.h>
#include <button_gpio.h>
#include <esp_rmaker_core.h>
#include <esp_rmaker_standard_params.h>
#include <app_reset.h>

#include "app_priv.h"

static const char *TAG = "app_driver";

/* ---------- state ---------- */
static bool  g_fan_power    = false;
static int   g_fan_speed    = 0;            /* 0-100 % */
static bool  g_auto_mode    = DEFAULT_AUTO_MODE;

static int   g_lux_threshold      = DEFAULT_LUX_THRESHOLD;
static int   g_humidity_threshold  = DEFAULT_HUMIDITY_THRESHOLD;
static int   g_temp_threshold      = DEFAULT_TEMP_THRESHOLD;

static float g_current_lux      = 0;
static float g_current_temp     = 0;
static float g_current_humidity = 0;

static int64_t g_auto_hold_start = 0;       /* ms timestamp, 0 = not holding */

/* ---------- button ---------- */
#define BUTTON_GPIO                 CONFIG_EXAMPLE_BOARD_BUTTON_GPIO
#define BUTTON_ACTIVE_LEVEL         0
#define WIFI_RESET_BUTTON_TIMEOUT   3
#define FACTORY_RESET_BUTTON_TIMEOUT 10

/* ---------- LEDC ---------- */
#define FAN_LEDC_TIMER      LEDC_TIMER_1
#define FAN_LEDC_CHANNEL    LEDC_CHANNEL_3
#define FAN_LEDC_MODE       LEDC_LOW_SPEED_MODE

/* ================================================================
 *  I2C helpers
 * ================================================================ */
static esp_err_t i2c_bus_init(void)
{
    i2c_config_t conf = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = I2C_SDA_GPIO,
        .scl_io_num = I2C_SCL_GPIO,
        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        .scl_pullup_en = GPIO_PULLUP_ENABLE,
        .master.clk_speed = I2C_FREQ_HZ,
    };
    ESP_ERROR_CHECK(i2c_param_config(I2C_PORT_NUM, &conf));
    return i2c_driver_install(I2C_PORT_NUM, conf.mode, 0, 0, 0);
}

static esp_err_t i2c_write_bytes(uint8_t addr, const uint8_t *data, size_t len)
{
    i2c_cmd_handle_t cmd = i2c_cmd_link_create();
    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, (addr << 1) | I2C_MASTER_WRITE, true);
    i2c_master_write(cmd, data, len, true);
    i2c_master_stop(cmd);
    esp_err_t ret = i2c_master_cmd_begin(I2C_PORT_NUM, cmd, pdMS_TO_TICKS(100));
    i2c_cmd_link_delete(cmd);
    return ret;
}

static esp_err_t i2c_write_reg16(uint8_t addr, uint8_t reg, uint16_t val)
{
    uint8_t buf[3] = { reg, val & 0xFF, (val >> 8) & 0xFF };
    return i2c_write_bytes(addr, buf, sizeof(buf));
}

static esp_err_t i2c_read_reg16(uint8_t addr, uint8_t reg, uint16_t *out)
{
    uint8_t data[2];
    i2c_cmd_handle_t cmd = i2c_cmd_link_create();
    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, (addr << 1) | I2C_MASTER_WRITE, true);
    i2c_master_write_byte(cmd, reg, true);
    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, (addr << 1) | I2C_MASTER_READ, true);
    i2c_master_read(cmd, data, 2, I2C_MASTER_LAST_NACK);
    i2c_master_stop(cmd);
    esp_err_t ret = i2c_master_cmd_begin(I2C_PORT_NUM, cmd, pdMS_TO_TICKS(100));
    i2c_cmd_link_delete(cmd);
    if (ret == ESP_OK) {
        *out = ((uint16_t)data[1] << 8) | data[0];   /* VEML7700 is LSB-first */
    }
    return ret;
}

/* ================================================================
 *  VEML7700  (ambient light)
 * ================================================================ */
static esp_err_t veml7700_init(void)
{
    /* ALS_CONF (reg 0x00): gain 1x, IT 100 ms, persistence 1, ALS enable */
    uint16_t conf = (0b0001 << 6);   /* IT = 100 ms; gain = 1x (bits 12:11 = 00) */
    return i2c_write_reg16(VEML7700_I2C_ADDR, 0x00, conf);
}

static esp_err_t veml7700_read_lux(float *lux)
{
    uint16_t raw;
    esp_err_t ret = i2c_read_reg16(VEML7700_I2C_ADDR, 0x04, &raw);
    if (ret == ESP_OK) {
        *lux = raw * 0.0576f;   /* resolution for gain=1x, IT=100ms */
    }
    return ret;
}

/* ================================================================
 *  AHT21  (temperature + humidity)
 * ================================================================ */
static esp_err_t aht21_init(void)
{
    uint8_t init_cmd[] = { 0xBE, 0x08, 0x00 };
    esp_err_t ret = i2c_write_bytes(AHT21_I2C_ADDR, init_cmd, sizeof(init_cmd));
    vTaskDelay(pdMS_TO_TICKS(40));
    return ret;
}

static esp_err_t aht21_read(float *temperature, float *humidity)
{
    /* trigger measurement */
    uint8_t trigger[] = { 0xAC, 0x33, 0x00 };
    esp_err_t ret = i2c_write_bytes(AHT21_I2C_ADDR, trigger, sizeof(trigger));
    if (ret != ESP_OK) return ret;

    vTaskDelay(pdMS_TO_TICKS(80));

    /* read 7 bytes: status  h[19:12]  h[11:4]  h[3:0]|t[19:16]  t[15:8]  t[7:0]  crc */
    uint8_t data[7];
    i2c_cmd_handle_t cmd = i2c_cmd_link_create();
    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, (AHT21_I2C_ADDR << 1) | I2C_MASTER_READ, true);
    i2c_master_read(cmd, data, sizeof(data), I2C_MASTER_LAST_NACK);
    i2c_master_stop(cmd);
    ret = i2c_master_cmd_begin(I2C_PORT_NUM, cmd, pdMS_TO_TICKS(100));
    i2c_cmd_link_delete(cmd);
    if (ret != ESP_OK) return ret;

    if (data[0] & 0x80) return ESP_ERR_NOT_FINISHED;   /* busy */

    uint32_t raw_hum  = ((uint32_t)data[1] << 12) | ((uint32_t)data[2] << 4) | (data[3] >> 4);
    uint32_t raw_temp = ((uint32_t)(data[3] & 0x0F) << 16) | ((uint32_t)data[4] << 8) | data[5];

    *humidity    = (raw_hum  * 100.0f) / (1 << 20);
    *temperature = (raw_temp * 200.0f) / (1 << 20) - 50.0f;
    return ESP_OK;
}

/* ================================================================
 *  Fan PWM
 * ================================================================ */
static esp_err_t fan_pwm_init(void)
{
    ledc_timer_config_t timer_conf = {
        .speed_mode     = FAN_LEDC_MODE,
        .timer_num      = FAN_LEDC_TIMER,
        .duty_resolution = FAN_PWM_RESOLUTION,
        .freq_hz        = FAN_PWM_FREQ_HZ,
        .clk_cfg        = LEDC_AUTO_CLK,
    };
    ESP_ERROR_CHECK(ledc_timer_config(&timer_conf));

    ledc_channel_config_t ch_conf = {
        .speed_mode = FAN_LEDC_MODE,
        .channel    = FAN_LEDC_CHANNEL,
        .timer_sel  = FAN_LEDC_TIMER,
        .gpio_num   = FAN_PWM_GPIO,
        .duty       = 0,
        .hpoint     = 0,
    };
    return ledc_channel_config(&ch_conf);
}

static void fan_set_duty(int speed_pct)
{
    uint32_t duty;
    if (speed_pct <= 0) {
        duty = 0;
    } else {
        uint32_t min_duty = (FAN_MIN_DUTY_PCT * FAN_MAX_DUTY) / 100;
        duty = min_duty + ((uint32_t)(FAN_MAX_DUTY - min_duty) * speed_pct) / 100;
        if (duty > (uint32_t)FAN_MAX_DUTY) duty = FAN_MAX_DUTY;
    }
    ledc_set_duty(FAN_LEDC_MODE, FAN_LEDC_CHANNEL, duty);
    ledc_update_duty(FAN_LEDC_MODE, FAN_LEDC_CHANNEL);
}

static void fan_apply_state(void)
{
    fan_set_duty(g_fan_power ? g_fan_speed : 0);
}

/* ================================================================
 *  RainMaker param reporting helper
 * ================================================================ */
static void report_param_float(const char *name, float val)
{
    if (!fan_device) return;
    esp_rmaker_param_t *p = esp_rmaker_device_get_param_by_name(fan_device, name);
    if (p) esp_rmaker_param_update_and_report(p, esp_rmaker_float(val));
}

static void report_param_bool(const char *name, bool val)
{
    if (!fan_device) return;
    esp_rmaker_param_t *p = esp_rmaker_device_get_param_by_name(fan_device, name);
    if (p) esp_rmaker_param_update_and_report(p, esp_rmaker_bool(val));
}

static void report_param_int(const char *name, int val)
{
    if (!fan_device) return;
    esp_rmaker_param_t *p = esp_rmaker_device_get_param_by_name(fan_device, name);
    if (p) esp_rmaker_param_update_and_report(p, esp_rmaker_int(val));
}

/* ================================================================
 *  Auto-trigger logic  (absolute thresholds)
 *
 *  In auto mode the fan is fully sensor-driven:
 *    sensor value > threshold  →  fan ON
 *    all values below          →  hold 3 min, then fan OFF
 * ================================================================ */
static void check_auto_triggers(void)
{
    if (!g_auto_mode) return;

    bool lux_triggered  = g_current_lux      > (float)g_lux_threshold;
    bool hum_triggered  = g_current_humidity  > (float)g_humidity_threshold;
    bool temp_triggered = g_current_temp      > (float)g_temp_threshold;
    bool any_triggered  = lux_triggered || hum_triggered || temp_triggered;

    if (any_triggered) {
        g_auto_hold_start = 0;                  /* reset hold timer */
        if (!g_fan_power) {
            g_fan_power = true;
            if (g_fan_speed == 0) g_fan_speed = DEFAULT_FAN_SPEED;
            fan_apply_state();
            ESP_LOGI(TAG, "Auto ON  (lux=%d hum=%d temp=%d)",
                     lux_triggered, hum_triggered, temp_triggered);
            report_param_bool("Power", true);
            report_param_int("Speed", g_fan_speed);
        }
    } else if (g_fan_power) {
        /* all below thresholds – turn off immediately */
        g_fan_power = false;
        fan_apply_state();
        ESP_LOGI(TAG, "Auto OFF (all below thresholds)");
        report_param_bool("Power", false);
    }
}

/* ================================================================
 *  Sensor task  (reads every SENSOR_READ_INTERVAL_MS)
 * ================================================================ */
static void sensor_task(void *arg)
{
    while (1) {
        /* ---- read VEML7700 ---- */
        float lux;
        if (veml7700_read_lux(&lux) == ESP_OK) {
            g_current_lux = lux;
        } else {
            ESP_LOGW(TAG, "VEML7700 read failed");
        }

        /* ---- read AHT21 ---- */
        float temp, hum;
        if (aht21_read(&temp, &hum) == ESP_OK) {
            g_current_temp     = temp;
            g_current_humidity = hum;
        } else {
            ESP_LOGW(TAG, "AHT21 read failed");
        }

        /* ---- auto-trigger ---- */
        check_auto_triggers();

        /* ---- report to cloud ---- */
        report_param_float("Temperature", g_current_temp);
        report_param_float("Humidity",    g_current_humidity);
        report_param_float("Lux",         g_current_lux);

        ESP_LOGI(TAG, "T=%.1f C  H=%.1f %%  L=%.1f lux | Fan %s %d%%",
                 g_current_temp, g_current_humidity, g_current_lux,
                 g_fan_power ? "ON" : "OFF", g_fan_speed);

        vTaskDelay(pdMS_TO_TICKS(SENSOR_READ_INTERVAL_MS));
    }
}

/* ================================================================
 *  Button callback – toggle fan
 * ================================================================ */
static void push_btn_cb(void *arg, void *data)
{
    g_fan_power = !g_fan_power;
    if (g_fan_power && g_fan_speed == 0) {
        g_fan_speed = DEFAULT_FAN_SPEED;
    }
    g_auto_hold_start = 0;
    fan_apply_state();

    report_param_bool("Power", g_fan_power);
    report_param_int("Speed",  g_fan_speed);
}

/* ================================================================
 *  Public API
 * ================================================================ */
void app_driver_init(void)
{
    /* ---- button ---- */
    button_config_t btn_cfg = { .long_press_time = 0, .short_press_time = 0 };
    button_gpio_config_t gpio_cfg = {
        .gpio_num = BUTTON_GPIO,
        .active_level = BUTTON_ACTIVE_LEVEL,
        .enable_power_save = false,
    };
    button_handle_t btn_handle = NULL;
    if (iot_button_new_gpio_device(&btn_cfg, &gpio_cfg, &btn_handle) == ESP_OK && btn_handle) {
        iot_button_register_cb(btn_handle, BUTTON_SINGLE_CLICK, NULL, push_btn_cb, NULL);
        app_reset_button_register(btn_handle, WIFI_RESET_BUTTON_TIMEOUT, FACTORY_RESET_BUTTON_TIMEOUT);
    }

    /* ---- I2C bus ---- */
    ESP_ERROR_CHECK(i2c_bus_init());

    /* ---- sensors ---- */
    esp_err_t ret = veml7700_init();
    if (ret != ESP_OK) ESP_LOGW(TAG, "VEML7700 init failed: %s", esp_err_to_name(ret));

    ret = aht21_init();
    if (ret != ESP_OK) ESP_LOGW(TAG, "AHT21 init failed: %s", esp_err_to_name(ret));

    /* ---- fan PWM ---- */
    ESP_ERROR_CHECK(fan_pwm_init());

    /* ---- sensor task ---- */
    xTaskCreate(sensor_task, "sensor_task", 4096, NULL, 5, NULL);
}

void app_driver_set_fan_power(bool on)
{
    g_fan_power = on;
    if (on && g_fan_speed == 0) g_fan_speed = DEFAULT_FAN_SPEED;
    g_auto_hold_start = 0;
    fan_apply_state();
}

bool app_driver_get_fan_power(void) { return g_fan_power; }

void app_driver_set_fan_speed(int speed_pct)
{
    if (speed_pct < 0)   speed_pct = 0;
    if (speed_pct > 100) speed_pct = 100;
    g_fan_speed = speed_pct;
    fan_apply_state();
}

int app_driver_get_fan_speed(void) { return g_fan_speed; }

void app_driver_set_auto_mode(bool enabled)  { g_auto_mode = enabled; }
bool app_driver_get_auto_mode(void)          { return g_auto_mode; }

void app_driver_set_lux_threshold(int val)      { g_lux_threshold = val; }
void app_driver_set_humidity_threshold(int val)  { g_humidity_threshold = val; }
void app_driver_set_temp_threshold(int val)      { g_temp_threshold = val; }

float app_driver_get_lux(void)         { return g_current_lux; }
float app_driver_get_temperature(void) { return g_current_temp; }
float app_driver_get_humidity(void)    { return g_current_humidity; }
