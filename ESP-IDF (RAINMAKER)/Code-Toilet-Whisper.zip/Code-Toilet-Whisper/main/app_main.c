/*
   Toilet-Whisper Fan Controller – RainMaker application
   Fan device with speed slider, sensor readouts, and auto-trigger thresholds.
*/
#include <string.h>
#include <inttypes.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <esp_log.h>
#include <esp_event.h>
#include <nvs_flash.h>

#include <esp_rmaker_core.h>
#include <esp_rmaker_standard_types.h>
#include <esp_rmaker_standard_params.h>
#include <esp_rmaker_standard_devices.h>
#include <esp_rmaker_schedule.h>
#include <esp_rmaker_scenes.h>
#include <esp_rmaker_console.h>
#include <esp_rmaker_ota.h>
#include <esp_rmaker_common_events.h>

#include <app_network.h>
#include <app_insights.h>

#include "app_priv.h"

static const char *TAG = "app_main";
esp_rmaker_device_t *fan_device;

/* ================================================================
 *  Write callback – commands from cloud / app
 * ================================================================ */
static esp_err_t write_cb(const esp_rmaker_device_t *device, const esp_rmaker_param_t *param,
            const esp_rmaker_param_val_t val, void *priv_data, esp_rmaker_write_ctx_t *ctx)
{
    if (ctx) {
        ESP_LOGI(TAG, "Received write request via : %s", esp_rmaker_device_cb_src_to_str(ctx->src));
    }

    const char *name = esp_rmaker_param_get_name(param);

    if (strcmp(name, "Power") == 0) {
        ESP_LOGI(TAG, "Power = %s", val.val.b ? "true" : "false");
        app_driver_set_fan_power(val.val.b);
        esp_rmaker_param_update(param, val);
    } else if (strcmp(name, "Speed") == 0) {
        ESP_LOGI(TAG, "Speed = %d", val.val.i);
        app_driver_set_fan_speed(val.val.i);
        esp_rmaker_param_update(param, val);
    } else if (strcmp(name, "Auto Mode") == 0) {
        ESP_LOGI(TAG, "Auto Mode = %s", val.val.b ? "true" : "false");
        app_driver_set_auto_mode(val.val.b);
        esp_rmaker_param_update(param, val);
    } else if (strcmp(name, "Lux Threshold") == 0) {
        ESP_LOGI(TAG, "Lux Threshold = %d", val.val.i);
        app_driver_set_lux_threshold(val.val.i);
        esp_rmaker_param_update(param, val);
    } else if (strcmp(name, "Humidity Threshold") == 0) {
        ESP_LOGI(TAG, "Humidity Threshold = %d", val.val.i);
        app_driver_set_humidity_threshold(val.val.i);
        esp_rmaker_param_update(param, val);
    } else if (strcmp(name, "Temp Threshold") == 0) {
        ESP_LOGI(TAG, "Temp Threshold = %d", val.val.i);
        app_driver_set_temp_threshold(val.val.i);
        esp_rmaker_param_update(param, val);
    }

    return ESP_OK;
}

/* ================================================================
 *  Event handler
 * ================================================================ */
static void event_handler(void* arg, esp_event_base_t event_base,
                          int32_t event_id, void* event_data)
{
    if (event_base == RMAKER_EVENT) {
        switch (event_id) {
            case RMAKER_EVENT_INIT_DONE:
                ESP_LOGI(TAG, "RainMaker Initialised.");
                break;
            case RMAKER_EVENT_CLAIM_STARTED:
                ESP_LOGI(TAG, "RainMaker Claim Started.");
                break;
            case RMAKER_EVENT_CLAIM_SUCCESSFUL:
                ESP_LOGI(TAG, "RainMaker Claim Successful.");
                break;
            case RMAKER_EVENT_CLAIM_FAILED:
                ESP_LOGI(TAG, "RainMaker Claim Failed.");
                break;
            case RMAKER_EVENT_LOCAL_CTRL_STARTED:
                ESP_LOGI(TAG, "Local Control Started.");
                break;
            case RMAKER_EVENT_LOCAL_CTRL_STOPPED:
                ESP_LOGI(TAG, "Local Control Stopped.");
                break;
            default:
                ESP_LOGW(TAG, "Unhandled RainMaker Event: %"PRIi32, event_id);
        }
    } else if (event_base == RMAKER_COMMON_EVENT) {
        switch (event_id) {
            case RMAKER_EVENT_REBOOT:
                ESP_LOGI(TAG, "Rebooting in %d seconds.", *((uint8_t *)event_data));
                break;
            case RMAKER_EVENT_WIFI_RESET:
                ESP_LOGI(TAG, "Wi-Fi credentials reset.");
                break;
            case RMAKER_EVENT_FACTORY_RESET:
                ESP_LOGI(TAG, "Node reset to factory defaults.");
                break;
            case RMAKER_MQTT_EVENT_CONNECTED:
                ESP_LOGI(TAG, "MQTT Connected.");
                break;
            case RMAKER_MQTT_EVENT_DISCONNECTED:
                ESP_LOGI(TAG, "MQTT Disconnected.");
                break;
            case RMAKER_MQTT_EVENT_PUBLISHED:
                ESP_LOGI(TAG, "MQTT Published. Msg id: %d.", *((int *)event_data));
                break;
            default:
                ESP_LOGW(TAG, "Unhandled RainMaker Common Event: %"PRIi32, event_id);
        }
    } else if (event_base == APP_NETWORK_EVENT) {
        switch (event_id) {
            case APP_NETWORK_EVENT_QR_DISPLAY:
                ESP_LOGI(TAG, "Provisioning QR : %s", (char *)event_data);
                break;
            case APP_NETWORK_EVENT_PROV_TIMEOUT:
                ESP_LOGI(TAG, "Provisioning Timed Out. Please reboot.");
                break;
            case APP_NETWORK_EVENT_PROV_RESTART:
                ESP_LOGI(TAG, "Provisioning has restarted due to failures.");
                break;
            default:
                ESP_LOGW(TAG, "Unhandled App Wi-Fi Event: %"PRIi32, event_id);
                break;
        }
    } else if (event_base == RMAKER_OTA_EVENT) {
        switch(event_id) {
            case RMAKER_OTA_EVENT_STARTING:
                ESP_LOGI(TAG, "Starting OTA.");
                break;
            case RMAKER_OTA_EVENT_IN_PROGRESS:
                ESP_LOGI(TAG, "OTA is in progress.");
                break;
            case RMAKER_OTA_EVENT_SUCCESSFUL:
                ESP_LOGI(TAG, "OTA successful.");
                break;
            case RMAKER_OTA_EVENT_FAILED:
                ESP_LOGI(TAG, "OTA Failed.");
                break;
            case RMAKER_OTA_EVENT_REJECTED:
                ESP_LOGI(TAG, "OTA Rejected.");
                break;
            case RMAKER_OTA_EVENT_DELAYED:
                ESP_LOGI(TAG, "OTA Delayed.");
                break;
            case RMAKER_OTA_EVENT_REQ_FOR_REBOOT:
                ESP_LOGI(TAG, "Firmware image downloaded. Please reboot to apply.");
                break;
            default:
                ESP_LOGW(TAG, "Unhandled OTA Event: %"PRIi32, event_id);
                break;
        }
    } else {
        ESP_LOGW(TAG, "Invalid event received!");
    }
}

/* ================================================================
 *  app_main
 * ================================================================ */
void app_main()
{
    esp_rmaker_console_init();
    app_driver_init();

    /* NVS */
    esp_err_t err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        err = nvs_flash_init();
    }
    ESP_ERROR_CHECK(err);

    app_network_init();

    /* Event handlers */
    ESP_ERROR_CHECK(esp_event_handler_register(RMAKER_EVENT, ESP_EVENT_ANY_ID, &event_handler, NULL));
    ESP_ERROR_CHECK(esp_event_handler_register(RMAKER_COMMON_EVENT, ESP_EVENT_ANY_ID, &event_handler, NULL));
    ESP_ERROR_CHECK(esp_event_handler_register(APP_NETWORK_EVENT, ESP_EVENT_ANY_ID, &event_handler, NULL));
    ESP_ERROR_CHECK(esp_event_handler_register(RMAKER_OTA_EVENT, ESP_EVENT_ANY_ID, &event_handler, NULL));

    /* RainMaker node */
    esp_rmaker_config_t rainmaker_cfg = {
        .enable_time_sync = false,
    };
    esp_rmaker_node_t *node = esp_rmaker_node_init(&rainmaker_cfg, "Toilet Whisper", "Fan");
    if (!node) {
        ESP_LOGE(TAG, "Could not initialise node. Aborting!!!");
        vTaskDelay(5000 / portTICK_PERIOD_MS);
        abort();
    }

    /* ---- Fan device ---- */
    fan_device = esp_rmaker_device_create("Fan", ESP_RMAKER_DEVICE_FAN, NULL);
    esp_rmaker_device_add_cb(fan_device, write_cb, NULL);

    /* Name */
    esp_rmaker_device_add_param(fan_device,
        esp_rmaker_name_param_create(ESP_RMAKER_DEF_NAME_PARAM, "Fan"));

    /* Power (toggle) – primary param */
    esp_rmaker_param_t *power_param = esp_rmaker_power_param_create(ESP_RMAKER_DEF_POWER_NAME, false);
    esp_rmaker_device_add_param(fan_device, power_param);
    esp_rmaker_device_assign_primary_param(fan_device, power_param);

    /* Speed (slider 0-100) */
    esp_rmaker_param_t *speed_param = esp_rmaker_speed_param_create(ESP_RMAKER_DEF_SPEED_NAME, 0);
    esp_rmaker_param_add_bounds(speed_param, esp_rmaker_int(0), esp_rmaker_int(100), esp_rmaker_int(1));
    esp_rmaker_device_add_param(fan_device, speed_param);

    /* ---- Read-only sensor values ---- */
    esp_rmaker_param_t *temp_param = esp_rmaker_temperature_param_create("Temperature", 0);
    esp_rmaker_device_add_param(fan_device, temp_param);

    esp_rmaker_param_t *hum_param = esp_rmaker_param_create("Humidity", NULL,
        esp_rmaker_float(0), PROP_FLAG_READ | PROP_FLAG_TIME_SERIES);
    esp_rmaker_param_add_ui_type(hum_param, ESP_RMAKER_UI_TEXT);
    esp_rmaker_device_add_param(fan_device, hum_param);

    esp_rmaker_param_t *lux_param = esp_rmaker_param_create("Lux", NULL,
        esp_rmaker_float(0), PROP_FLAG_READ | PROP_FLAG_TIME_SERIES);
    esp_rmaker_param_add_ui_type(lux_param, ESP_RMAKER_UI_TEXT);
    esp_rmaker_device_add_param(fan_device, lux_param);

    /* ---- Auto-trigger controls ---- */
    esp_rmaker_param_t *auto_param = esp_rmaker_param_create("Auto Mode", NULL,
        esp_rmaker_bool(DEFAULT_AUTO_MODE), PROP_FLAG_READ | PROP_FLAG_WRITE);
    esp_rmaker_param_add_ui_type(auto_param, ESP_RMAKER_UI_TOGGLE);
    esp_rmaker_device_add_param(fan_device, auto_param);

    esp_rmaker_param_t *lux_thresh = esp_rmaker_param_create("Lux Threshold", NULL,
        esp_rmaker_int(DEFAULT_LUX_THRESHOLD), PROP_FLAG_READ | PROP_FLAG_WRITE);
    esp_rmaker_param_add_ui_type(lux_thresh, ESP_RMAKER_UI_SLIDER);
    esp_rmaker_param_add_bounds(lux_thresh, esp_rmaker_int(5), esp_rmaker_int(200), esp_rmaker_int(5));
    esp_rmaker_device_add_param(fan_device, lux_thresh);

    esp_rmaker_param_t *hum_thresh = esp_rmaker_param_create("Humidity Threshold", NULL,
        esp_rmaker_int(DEFAULT_HUMIDITY_THRESHOLD), PROP_FLAG_READ | PROP_FLAG_WRITE);
    esp_rmaker_param_add_ui_type(hum_thresh, ESP_RMAKER_UI_SLIDER);
    esp_rmaker_param_add_bounds(hum_thresh, esp_rmaker_int(2), esp_rmaker_int(200), esp_rmaker_int(1));
    esp_rmaker_device_add_param(fan_device, hum_thresh);

    esp_rmaker_param_t *temp_thresh = esp_rmaker_param_create("Temp Threshold", NULL,
        esp_rmaker_int(DEFAULT_TEMP_THRESHOLD), PROP_FLAG_READ | PROP_FLAG_WRITE);
    esp_rmaker_param_add_ui_type(temp_thresh, ESP_RMAKER_UI_SLIDER);
    esp_rmaker_param_add_bounds(temp_thresh, esp_rmaker_int(1), esp_rmaker_int(40), esp_rmaker_int(1));
    esp_rmaker_device_add_param(fan_device, temp_thresh);

    /* Add device to node */
    esp_rmaker_node_add_device(node, fan_device);

    /* Services */
    esp_rmaker_ota_enable_default();
    esp_rmaker_timezone_service_enable();
    esp_rmaker_schedule_enable();
    esp_rmaker_scenes_enable();
    app_insights_enable();

    esp_rmaker_start();

    err = app_network_set_custom_mfg_data(MFG_DATA_DEVICE_TYPE_SWITCH, MFG_DATA_DEVICE_SUBTYPE_SWITCH);
    err = app_network_start(POP_TYPE_RANDOM);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Could not start Wifi. Aborting!!!");
        vTaskDelay(5000 / portTICK_PERIOD_MS);
        abort();
    }
}
