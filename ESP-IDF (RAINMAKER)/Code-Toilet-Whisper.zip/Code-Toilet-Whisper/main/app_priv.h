/*
   Toilet-Whisper Fan Controller
   ESP32-C3 + VEML7700 (lux) + AHT21 (temp/humidity) + PWM fan
*/
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <esp_err.h>
#include <esp_rmaker_core.h>

/* ---- GPIO Configuration (Toilet-Whisper board) ---- */
#define I2C_SDA_GPIO            6
#define I2C_SCL_GPIO            7
#define FAN_PWM_GPIO            3

/* ---- I2C ---- */
#define I2C_PORT_NUM            0
#define I2C_FREQ_HZ             400000
#define VEML7700_I2C_ADDR       0x10
#define AHT21_I2C_ADDR          0x38

/* ---- Fan PWM ---- */
#define FAN_PWM_FREQ_HZ         25000
#define FAN_PWM_RESOLUTION      10          /* 10-bit: 0-1023 */
#define FAN_MAX_DUTY            ((1 << FAN_PWM_RESOLUTION) - 1)
#define FAN_MIN_DUTY_PCT        45          /* minimum % to spin the motor */

/* ---- Default thresholds for auto-trigger (absolute values) ---- */
#define DEFAULT_LUX_THRESHOLD       35      /* lux above this = light on */
#define DEFAULT_HUMIDITY_THRESHOLD   70      /* %RH above this = too humid */
#define DEFAULT_TEMP_THRESHOLD       30     /* deg-C above this = too hot */
#define DEFAULT_FAN_SPEED            70      /* % when auto-started */
#define DEFAULT_AUTO_MODE            true

/* ---- Timing ---- */
#define SENSOR_READ_INTERVAL_MS     5000
#define AUTO_HOLD_TIME_MS           180000  /* 3 min hold after triggers clear */

/* ---- RainMaker device ---- */
extern esp_rmaker_device_t *fan_device;

/* ---- Driver API ---- */
void app_driver_init(void);

void app_driver_set_fan_power(bool on);
bool app_driver_get_fan_power(void);

void app_driver_set_fan_speed(int speed_pct);
int  app_driver_get_fan_speed(void);

void app_driver_set_auto_mode(bool enabled);
bool app_driver_get_auto_mode(void);

void app_driver_set_lux_threshold(int val);
void app_driver_set_humidity_threshold(int val);
void app_driver_set_temp_threshold(int val);

float app_driver_get_lux(void);
float app_driver_get_temperature(void);
float app_driver_get_humidity(void);
